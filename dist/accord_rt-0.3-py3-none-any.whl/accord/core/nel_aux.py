import importlib.resources
import pathlib
import shutil

import pylinac.calibration.trs398
import tomllib

# This file contains auxiliary functions for the NEL calibration process.

# Copy sample files.
def copy_sample_files(path: pathlib.Path, file_class: str):
    configTraversable_list = list()
    if file_class == "config":
        configTraversable_list.append(importlib.resources.files("accord").joinpath("sampleFiles/config.toml"))
    elif file_class == "calibration":
        configTraversable_list.append(importlib.resources.files("accord").joinpath("sampleFiles/calibration.toml"))
        # TODO: make file_class a list of paths to work with the three preliminary.csv original files.
    elif file_class == "preliminary":
        configTraversable_list.append(importlib.resources.files("accord").joinpath("sampleFiles/preliminary_0.csv"))
        configTraversable_list.append(importlib.resources.files("accord").joinpath("sampleFiles/preliminary_1.csv"))
        configTraversable_list.append(importlib.resources.files("accord").joinpath("sampleFiles/preliminary_2.csv"))
    elif file_class == "devices":
        configTraversable_list.append(importlib.resources.files("accord").joinpath("sampleFiles/devices.toml"))
    else:
        raise ValueError("Invalid file type. Please choose 'config', 'calibration', 'preliminary', or 'devices'.")

    for configTraversable in configTraversable_list:
        with importlib.resources.as_file(configTraversable) as configPath:
            if (path/configPath.name).exists():
                raise FileExistsError
            shutil.copy(configPath, path)
            # print(f"File copied.")
    

# Load a TOML file
def load_toml_file(path: pathlib.Path) -> dict[str, object]:
    with open(path, "rb") as f:
        return tomllib.load(f)

# Get a nested value in a dictionary
def get_nested(dictObj, *keys, default=None):
    for key in keys:
        if isinstance(dictObj, dict):
            dictObj = dictObj.get(key)
        else:
            return default
    return dictObj if dictObj is not None else default

# Validate option helper.
def resolve_option2(cli_value, config, key_path):
    keys = key_path.split(".")
    value = cli_value or get_nested(config, *keys)

    # if value is None:
    #     raise ValueError(f"Missing required option: --{keys[-1]} or '{key_path}' in config.")
    return value

# Example calibration data structure used in the calibration file.
calibration_data = {
    "chamber":"30013",
    "clinical_pdd_zref": 66.5,
    "energy": 6,
    "fff": False,
    "institution": "Your institution here",
    "k_elec": 1.000,
    "m_opposite": [25.64, 25.65, 25.65],
    "m_reference": [25.65, 25.66, 25.65],
    "m_reduced": [25.64, 25.63, 25.63],
    "measurement_date": "2025-05-16",
    "mu": 200,
    "n_dw": 5.443,
    "physicist": "Person realizing the calibration",
    "press": 100.65839,
    "setup": "SSD",
    "temp": 22.1,
    "tissue_correction": 1.0,
    "tpr2010": 0.573573574,
    "unit": "Unit employed",
    "voltage_reduced": -150,
    "voltage_reference": -300,
    "notes": "Sample note."
}

def GetBaseTypes(config_quantities: dict) -> dict:
    """
    Get the base types of the quantities from the config file.
    """
    baseTypes = dict()
    for key in config_quantities:
        baseTypes[key] = config_quantities[key]["baseType"]
    return baseTypes

def Row2Measurement(row: dict, baseTypes: dict) -> dict:
    """
    Convert a row from the CSV file into a measurement dictionary.
    """
    measurement = dict()
    for key in row:
        if baseTypes[key] == "int":
            measurement[key] = int(row[key])
        elif baseTypes[key] == "float":
            measurement[key] = float(row[key])

    return measurement

def Row2Measurement2(row: dict, quantities: dict) -> dict:
    """
    Convert a dictionary containing a row from the CSV file to a dictionary containing the same values but with the correct base types.
    Base types are obtained from the quantities dictionary in the json file.
    """
    measurement = dict()
    for key in row:
        if quantities[key]["baseType"] == "int":
            measurement[key] = int(row[key])
        elif quantities[key]["baseType"] == "float":
            measurement[key] = float(row[key])
        elif quantities[key]["baseType"] == "str":
            measurement[key] = row[key]
        elif quantities[key]["baseType"] == "bool":
            measurement[key] = row[key].lower() in ("true")

    return measurement

def ConvertMeasurement(rawMeasurement: dict, oldUnits: dict, newUnits: dict) -> dict:
    """
    Converts raw measurement in old units to new units.
    """
    measurement = rawMeasurement.copy()
    for key in rawMeasurement:
        if oldUnits[key] != newUnits[key]:
            if key == "T":
                # measurement[key] = trs398.convert_temperature(rawMeasurement[key], oldUnits[key], newUnits[key])
                if oldUnits[key] == "°F":
                    measurement[key] = pylinac.calibration.trs398.fahrenheit2celsius(rawMeasurement[key])
                elif oldUnits[key] == "K":
                    measurement[key] = rawMeasurement[key] + 273
            elif key == "P":
                # measurement[key] = trs398.convert_pressure(rawMeasurement[key], oldUnits[key], newUnits[key])
                if oldUnits[key] == "mbar":
                    measurement[key] = pylinac.calibration.trs398.mbar2kPa(rawMeasurement[key])
                elif oldUnits[key] == "mmHg":
                    measurement[key] = pylinac.calibration.trs398.mmHg2kPa(rawMeasurement[key])
            # elif key == "m":
            #     measurement[key] = trs398.convert_charge(rawMeasurement[key], oldUnits[key], newUnits[key])
            # elif key == "k_TP":
            #     measurement[key] = trs398.convert_temperature_pressure_correction_factor(rawMeasurement["T"], rawMeasurement["P"], oldUnits["T"], oldUnits["P"], newUnits["T"], newUnits["P"])
            # elif key == "m_corrected":
            #     measurement[key] = trs398.convert_charge(rawMeasurement[key], oldUnits[key], newUnits[key])
    return measurement

def Convert_measurement_to_pylinac_units(measurement: dict, oldUnits: dict) -> dict:
    converted_measurement = measurement.copy()
    for key in converted_measurement:
        if key == "T":
            if oldUnits[key] == "°F":
                converted_measurement[key] = pylinac.calibration.trs398.fahrenheit2celsius(converted_measurement[key])
            elif oldUnits[key] == "°C":
                pass
            else:
                raise ValueError(f"Invalid temperature unit: {oldUnits[key]}")
        elif key == "P":
            if oldUnits[key] == "mbar":
                converted_measurement[key] = pylinac.calibration.trs398.mbar2kPa(converted_measurement[key])
            elif oldUnits[key] == "mmHg":
                converted_measurement[key] = pylinac.calibration.trs398.mmHg2kPa(converted_measurement[key])
            elif oldUnits[key] == "kPa":
                pass
            else:
                raise ValueError(f"Invalid pressure unit: {oldUnits[key]}")
            
    return converted_measurement

def FindAverage(numberList: list) -> float:
    acum = 0
    for number in numberList:
        acum = acum + number
    # DEBUG: FAIL. With empty value .csv input files.
    return acum / len(numberList)

def FindStdDev(numberList: list) -> float:
    average = FindAverage(numberList)
    acum = 0
    for number in numberList:
        acum = acum + (number - average) ** 2
    return (acum / (len(numberList)-1)) ** 0.5

def FindExpectedValue(numberList: list) -> float:
    return FindAverage(numberList)

def main():
    return 0

if __name__ == "__main__":
    errorCode = main()
    print(f"Program terminated with errorCode: {errorCode}")